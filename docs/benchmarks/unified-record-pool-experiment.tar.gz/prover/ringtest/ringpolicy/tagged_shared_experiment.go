package ringpolicy

import (
	"github.com/helius-labs/zolana-custom-rings/prover/ringtest/ringregistry"
	"testing"
)

// Fixtures for this experiment carry no inline mint settings or caps.
func MeasurementRegistries(t testing.TB, w World) [2]*ringregistry.Registry {
	t.Helper()
	if len(w.Table.Inline) != 0 || len(w.Table.Limits) != 0 {
		t.Fatal("measurement fixture includes unsupported mint settings")
	}
	return [2]*ringregistry.Registry{registry(t, w.Own), registry(t, w.Curator)}
}
