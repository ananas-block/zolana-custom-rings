package ringregistry

import (
	"github.com/consensys/gnark/frontend"
	"github.com/helius-labs/zolana-custom-rings/prover/circuits/registry"
	"math/big"
)

func (r *Registry) MeasurementCanopy(width int) []frontend.Variable {
	levels := 0
	for n := width; n > 1; n /= 4 {
		levels++
	}
	nodes := make([]frontend.Variable, width)
	for i := range nodes {
		nodes[i] = new(big.Int).Set(r.node(registry.Height-levels, uint64(i)))
	}
	return nodes
}

func (r *Registry) MeasurementPath(index uint64, width int) registry.SharedQuadPath {
	levels := 0
	for n := width; n > 1; n /= 4 {
		levels++
	}
	path := r.Path(index).Wires()
	return registry.SharedQuadPath{Index: index, Siblings: append([][registry.Arity - 1]frontend.Variable{}, path.Siblings[:registry.Height-levels]...)}
}
