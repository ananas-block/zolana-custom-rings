package registry

import (
	"github.com/consensys/gnark/frontend"
	"github.com/consensys/gnark/std/lookup/logderivlookup"
	"github.com/consensys/gnark/std/selector"
	"github.com/helius-labs/zolana/prover/server/circuits/gadget"
	"github.com/reilabs/gnark-lean-extractor/v3/abstractor"
)

// Measurement prototype: each record chooses one of two separately authenticated
// canopies. Shared lower paths retain the production tree height and hash.
func AssertTaggedSharedExperiment(api frontend.API, ownRoot, curatorRoot, curatorActive frontend.Variable, canopies [2][]frontend.Variable, leaves, treeIDs []frontend.Variable, paths []SharedQuadPath) {
	api.AssertIsEqual(canopyRoot(api, canopies[0]), ownRoot)
	abstractor.CallVoid(api, gadget.AssertEqualWhen{Cond: curatorActive, A: canopyRoot(api, canopies[1]), B: curatorRoot})
	width := len(canopies[0])
	nodes := append(append([]frontend.Variable{}, canopies[0]...), canopies[1]...)
	if len(nodes) <= muxCanopyLimit {
		for i, path := range paths {
			node := path.root(api, leaves[i])
			bits := append(append([]frontend.Variable{}, node.bits...), treeIDs[i])
			api.AssertIsEqual(selector.BinaryMux(api, bits, nodes), node.value)
		}
		return
	}
	table := logderivlookup.New(api)
	for _, node := range nodes {
		table.Insert(node)
	}
	for i, path := range paths {
		node := path.root(api, leaves[i])
		index := api.Add(api.Mul(treeIDs[i], width), api.FromBinary(node.bits...))
		api.AssertIsEqual(table.Lookup(index)[0], node.value)
	}
}
