package policy_test

import (
	"encoding/json"
	"fmt"
	"github.com/consensys/gnark-crypto/ecc"
	"github.com/consensys/gnark/constraint"
	"github.com/consensys/gnark/frontend"
	"github.com/helius-labs/zolana-custom-rings/prover/circuits/policy"
	"github.com/helius-labs/zolana-custom-rings/prover/circuits/registry"
	"github.com/helius-labs/zolana-custom-rings/prover/ringtest"
	"github.com/helius-labs/zolana-custom-rings/prover/ringtest/ringkey"
	"github.com/helius-labs/zolana-custom-rings/prover/ringtest/ringpolicy"
	"github.com/helius-labs/zolana-custom-rings/prover/ringtest/ringregistry"
	"math/big"
	"os"
	"testing"
)

func unifiedFixture(t *testing.T, outputs, withdrawals, budget int, distinct bool) (*policy.UnifiedPoolExperiment, error) {
	t.Helper()
	shape := policy.MemberShape{Outputs: outputs, Withdrawals: withdrawals}
	world := poolWorld(shape, distinct, false)
	if !distinct {
		world.Public = nil
		if withdrawals > 0 {
			world.Public = []ringpolicy.PublicSlot{{Asset: ringpolicy.AssetA, Amount: -int64(withdrawals)}}
		}
	}
	for member, r := range world.Curator {
		r.Registered = false
		world.Curator[member] = r
	}
	return convertUnifiedFixture(t, world, budget)
}

func convertUnifiedFixture(t *testing.T, world ringpolicy.World, budget int) (*policy.UnifiedPoolExperiment, error) {
	t.Helper()
	w := world.Build(t).Member
	trees := ringpolicy.MeasurementRegistries(t, world)
	if trees[0].Root().Cmp(ringtest.AsBigInt(w.OwnRoot)) != 0 || trees[1].Root().Cmp(ringtest.AsBigInt(w.CuratorRoot)) != 0 {
		t.Fatal("fixture root mismatch")
	}
	u, err := policy.NewUnifiedPoolExperiment(world.Outputs, world.WithdrawalCapacity, budget, len(w.OwnSubjects)+len(w.CuratorSubjects))
	if err != nil {
		return nil, err
	}
	u.MemberPolicyValues, u.PolicyInputs = w.MemberPolicyValues, w.PolicyInputs
	var distinctRecords []policy.TaggedRecordExperiment
	var positions []uint64
	oldToNew := [2][]int{make([]int, len(w.OwnRecords)), make([]int, len(w.CuratorRecords))}
	for tree, records := range [][]registry.Record{w.OwnRecords, w.CuratorRecords} {
		proof := w.OwnProof
		if tree == 1 {
			proof = w.CuratorProof
		}
		seen := make(map[uint64]int)
		for i, record := range records {
			position := ringtest.AsBigInt(proof.Paths[i].Index).Uint64()
			index, found := seen[position]
			if !found {
				index = len(distinctRecords)
				seen[position] = index
				distinctRecords = append(distinctRecords, policy.TaggedRecordExperiment{TreeID: tree, Record: record})
				positions = append(positions, position)
			}
			oldToNew[tree][i] = index
		}
	}
	if len(distinctRecords) > budget {
		return nil, fmt.Errorf("need %d records, budget %d", len(distinctRecords), budget)
	}
	width := len(u.Canopies[0])
	for tree := range trees {
		u.Canopies[tree] = trees[tree].MeasurementCanopy(width)
	}
	for i := range u.Records {
		i0 := i % len(distinctRecords)
		u.Records[i] = distinctRecords[i0]
		tree := int(ringtest.AsBigInt(u.Records[i].TreeID).Int64())
		u.Paths[i] = trees[tree].MeasurementPath(positions[i0], width)
	}
	at := 0
	for tree, subjects := range [][]policy.PoolSubject{w.OwnSubjects, w.CuratorSubjects} {
		for _, subject := range subjects {
			index := int(ringtest.AsBigInt(subject.RecordIndex).Int64())
			u.Subjects[at] = policy.TaggedSubjectExperiment{TreeID: tree, Member: subject.Member, RecordIndex: oldToNew[tree][index]}
			at++
		}
	}
	remap := func(entry policy.PoolEntry) policy.PoolEntry {
		return policy.PoolEntry{Own: entry.Own, Curator: []frontend.Variable{int(ringtest.AsBigInt(entry.Curator[0]).Int64()) + len(w.OwnSubjects)}}
	}
	u.SenderEntry = remap(w.SenderEntry)
	for i := range u.OwnerEntries {
		u.OwnerEntries[i], u.AssetEntries[i] = remap(w.OwnerEntries[i]), remap(w.AssetEntries[i])
	}
	copy(u.PublicAssetEntries, w.PublicAssetEntries)
	return u, nil
}

func TestMeasureUnifiedPool(t *testing.T) {
	cases := []struct {
		outputs, withdrawals int
		budgets              []int
	}{{2, 0, []int{13, 8, 6}}, {4, 0, []int{21, 12, 6}}, {8, 0, []int{37, 20, 6}}, {16, 0, []int{69, 36, 16, 8, 6}}, {16, 32, []int{136, 68, 36, 16, 6}}}
	var results []map[string]any
	for _, tc := range cases {
		full, err := policy.NewMemberPolicyCircuit(policy.MemberShape{Outputs: tc.outputs, Withdrawals: tc.withdrawals})
		if err != nil {
			t.Fatal(err)
		}
		baseline := compileRuleBudget(t, full).GetNbConstraints()
		key := fmt.Sprintf("custom_ring_policy_member_v3_%d_w%d_curator", tc.outputs, tc.withdrawals)
		if baseline != ringkey.Pinned[key] {
			t.Fatal("baseline differs from production pin")
		}
		for _, budget := range tc.budgets {
			c, err := policy.NewUnifiedPoolExperiment(tc.outputs, tc.withdrawals, budget, len(full.OwnSubjects)+len(full.CuratorSubjects))
			if err != nil {
				t.Fatal(err)
			}
			cs := compileRuleBudget(t, c)
			witness, err := unifiedFixture(t, tc.outputs, tc.withdrawals, budget, false)
			if err != nil {
				t.Fatal(err)
			}
			solveRuleBudget(t, cs, witness)
			result := map[string]any{"outputs": tc.outputs, "withdrawal_capacity": tc.withdrawals, "baseline_own_records": len(full.OwnRecords), "baseline_curator_records": len(full.CuratorRecords), "unified_total_record_capacity": budget, "unified_subject_capacity": len(c.Subjects), "canopy_width_per_tree": len(c.Canopies[0]), "baseline_constraints": baseline, "unified_constraints": cs.GetNbConstraints(), "saved_constraints": baseline - cs.GetNbConstraints(), "honest_witness_solved": true}
			if budget == tc.budgets[0] {
				wide, err := unifiedFixture(t, tc.outputs, tc.withdrawals, budget, true)
				if err != nil {
					t.Fatal(err)
				}
				solveRuleBudget(t, cs, wide)
				result["distinct_subject_fixture_solved"] = true
			}
			if tc.outputs == 2 && budget == 6 {
				assertRejected := func(name string, mutate func(*policy.UnifiedPoolExperiment)) {
					w, err := unifiedFixture(t, 2, 0, 6, false)
					if err != nil {
						t.Fatal(err)
					}
					mutate(w)
					fw, err := frontend.NewWitness(w, ecc.BN254.ScalarField())
					if err != nil {
						t.Fatal(err)
					}
					if err := cs.IsSolved(fw); err == nil {
						t.Fatalf("accepted %s", name)
					}
					result[name] = true
				}
				assertRejected("wrong_record_tree_rejected", func(w *policy.UnifiedPoolExperiment) { w.Records[0].TreeID = 1 })
				assertRejected("nonboolean_tree_selector_rejected", func(w *policy.UnifiedPoolExperiment) { w.Records[0].TreeID = 2 })
				assertRejected("curator_subject_as_own_rejected", func(w *policy.UnifiedPoolExperiment) { w.SenderEntry.Own = w.SenderEntry.Curator[0] })
				assertRejected("altered_record_lists_rejected", func(w *policy.UnifiedPoolExperiment) {
					w.Records[0].Record.Lists = new(big.Int).Xor(ringtest.AsBigInt(w.Records[0].Record.Lists), big.NewInt(1))
				})
			}
			results = append(results, result)
			b, _ := json.Marshal(result)
			fmt.Printf("UNIFIED_POOL %s\n", b)
		}
	}
	report := map[string]any{"scope": "Experimental member-policy unified two-tree record pool, same leaf hash/rules/escrow/mint source restrictions, per-record boolean tree selector, both registry roots authenticated, shared canopy per tree. Original source-record pools replaced with one tagged record table and one tagged subject table. Subject capacities unchanged. Smaller record capacities support fewer distinct(tree,record) entries; no claim of same worst-case diversity at lower budget.", "results": results}
	b, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile("unified-pool-results.json", append(b, '\n'), 0600); err != nil {
		t.Fatal(err)
	}
}

func TestUnifiedPoolAbsence(t *testing.T) {
	world := poolWorld(policy.MemberShape{Outputs: 2}, false, false)
	world.KeyEscrow = false
	world.Own, world.Curator = map[int64]ringpolicy.Record{}, map[int64]ringpolicy.Record{}
	world.Table.Rules = []ringpolicy.Rule{ringpolicy.Forbid(policy.SubjectSender, ringregistry.FrozenBit), ringpolicy.Forbid(policy.SubjectOutputOwner, ringregistry.BlockBit), ringpolicy.Forbid(policy.SubjectAsset, ringregistry.BlockBit)}
	world.Table.Curator = map[uint64]bool{ringregistry.BlockBit: true}
	world.Public = nil
	w, err := convertUnifiedFixture(t, world, 2)
	if err != nil {
		t.Fatal(err)
	}
	c, err := policy.NewUnifiedPoolExperiment(2, 0, 2, len(w.Subjects))
	if err != nil {
		t.Fatal(err)
	}
	cs := compileRuleBudget(t, c)
	solveRuleBudget(t, cs, w)
	fmt.Printf("UNIFIED_ABSENCE_OK constraints=%d records=2\n", cs.GetNbConstraints())
}

func TestMeasureCompactSplit(t *testing.T) {
	var results []map[string]any
	for _, tc := range []struct{ withdrawals, perTree int }{{0, 18}, {0, 3}, {32, 34}, {32, 3}} {
		ownSubjects := 36 + tc.withdrawals
		curatorSubjects := 33 + tc.withdrawals + min(tc.withdrawals, 3)
		shape := policy.MemberShape{Outputs: 16, Withdrawals: tc.withdrawals, Records: policy.RecordPoolShape{Own: tc.perTree, Curator: tc.perTree, OwnSubjects: ownSubjects, CuratorSubjects: curatorSubjects}}
		c, err := policy.NewMemberPolicyCircuit(shape)
		if err != nil {
			t.Fatal(err)
		}
		cs := compileRuleBudget(t, c)
		world := poolWorld(shape, false, false)
		world.Public = nil
		if tc.withdrawals > 0 {
			world.Public = []ringpolicy.PublicSlot{{Asset: ringpolicy.AssetA, Amount: -int64(tc.withdrawals)}}
		}
		for member, r := range world.Curator {
			r.Registered = false
			world.Curator[member] = r
		}
		honest := world.Build(t)
		solveRuleBudget(t, cs, honest.Member)
		r := map[string]any{"outputs": 16, "withdrawal_capacity": tc.withdrawals, "own_records": tc.perTree, "curator_records": tc.perTree, "own_subjects": ownSubjects, "curator_subjects": curatorSubjects, "constraints": cs.GetNbConstraints(), "honest_witness_solved": true}
		results = append(results, r)
		b, _ := json.Marshal(r)
		fmt.Printf("COMPACT_SPLIT %s\n", b)
	}
	b, err := json.MarshalIndent(results, "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile("compact-split-results.json", append(b, '\n'), 0600); err != nil {
		t.Fatal(err)
	}
}

func TestUnifiedPoolCommitmentMetadata(t *testing.T) {
	for _, tc := range []struct{ outputs, withdrawals, records int }{{2, 0, 6}, {16, 0, 69}, {16, 32, 136}} {
		full, err := policy.NewMemberPolicyCircuit(policy.MemberShape{Outputs: tc.outputs, Withdrawals: tc.withdrawals})
		if err != nil {
			t.Fatal(err)
		}
		c, err := policy.NewUnifiedPoolExperiment(tc.outputs, tc.withdrawals, tc.records, len(full.OwnSubjects)+len(full.CuratorSubjects))
		if err != nil {
			t.Fatal(err)
		}
		cs := compileRuleBudget(t, c)
		commitments, ok := cs.GetCommitments().(constraint.Groth16Commitments)
		if !ok || len(commitments) != 1 || commitments[0].NbPublicCommitted != 0 {
			t.Fatalf("unexpected commitment metadata: %v", cs.GetCommitments())
		}
		if cs.GetNbPublicVariables()-1 != 1 {
			t.Fatal("expected one public input")
		}
	}
}
