package policy_test

import (
	"encoding/json"
	"fmt"
	"github.com/consensys/gnark-crypto/ecc"
	"github.com/consensys/gnark/constraint"
	"github.com/consensys/gnark/frontend"
	"github.com/consensys/gnark/frontend/cs/r1cs"
	"github.com/helius-labs/zolana-custom-rings/prover/circuits/policy"
	"github.com/helius-labs/zolana-custom-rings/prover/ringtest/ringkey"
	"github.com/helius-labs/zolana-custom-rings/prover/ringtest/ringpolicy"
	"os"
	"testing"
)

func compileRuleBudget(t *testing.T, c frontend.Circuit) constraint.ConstraintSystem {
	t.Helper()
	cs, err := frontend.Compile(ecc.BN254.ScalarField(), r1cs.NewBuilder, c, frontend.WithCompressThreshold(300))
	if err != nil {
		t.Fatal(err)
	}
	return cs
}

func solveRuleBudget(t *testing.T, cs constraint.ConstraintSystem, c frontend.Circuit) {
	t.Helper()
	w, err := frontend.NewWitness(c, ecc.BN254.ScalarField())
	if err != nil {
		t.Fatal(err)
	}
	if err := cs.IsSolved(w); err != nil {
		t.Fatal(err)
	}
}

func TestMeasureRuleBudget(t *testing.T) {
	results := make([]map[string]any, 0, 4)
	for _, outputs := range []int{2, 4, 8, 16} {
		world := ringpolicy.Confidential()
		world.Outputs, world.OwnOnly = outputs, true
		honest := world.Build(t)
		counts := make(map[int]int)
		for _, slots := range []int{-1, 0, 1, 16} {
			c, err := policy.NewRuleBudgetCircuit(outputs, slots)
			if err != nil {
				t.Fatal(err)
			}
			cs := compileRuleBudget(t, c)
			counts[slots] = cs.GetNbConstraints()
			solveRuleBudget(t, cs, &policy.RuleBudgetCircuit{MemberPolicyCircuit: *honest.Member, RuleSlots: slots})
		}
		key := fmt.Sprintf("custom_ring_policy_member_v3_%d_w0_own", outputs)
		if counts[16] != ringkey.Pinned[key] {
			t.Fatalf("full ablation %d differs from production pin %d", counts[16], ringkey.Pinned[key])
		}
		r := map[string]any{"outputs": outputs, "withdrawal_capacity": 0, "own_only": true, "production_constraints": counts[16], "without_rule_evaluation_constraints": counts[-1], "shared_preparation_only_constraints": counts[0], "one_dynamic_rule_constraints": counts[1], "shared_preparation_delta": counts[0] - counts[-1], "first_dynamic_rule_delta": counts[1] - counts[0], "sixteen_rule_loop_delta": counts[16] - counts[0], "total_rule_evaluation_delta": counts[16] - counts[-1], "all_honest_witnesses_solved": true, "matches_production_pin": true}
		results = append(results, r)
		encoded, _ := json.Marshal(r)
		fmt.Printf("RULE_BUDGET %s\n", encoded)
	}
	world := ringpolicy.Confidential()
	world.OwnOnly = true
	honest := world.Build(t)
	table := &policy.TableBudgetCircuit{}
	cs := compileRuleBudget(t, table)
	solveRuleBudget(t, cs, &policy.TableBudgetCircuit{Table: honest.Member.Table, PolicyHash: honest.Member.PolicyHash})
	report := map[string]any{"curve": "BN254", "backend": "gnark R1CS", "compress_threshold": 300, "note": "Integrated ablation deltas include compiler lookup/range-check amortization. Table hash and decoding remain enabled in all member-policy variants. Rule types and active rule count are witness data; the production key always includes all 16 dynamic rule slots.", "table_hash_and_decode_standalone_constraints": cs.GetNbConstraints(), "results": results}
	encoded, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile("rule-budget-results.json", append(encoded, '\n'), 0600); err != nil {
		t.Fatal(err)
	}
	fmt.Printf("TABLE_HASH_DECODE %d\n", cs.GetNbConstraints())
}
