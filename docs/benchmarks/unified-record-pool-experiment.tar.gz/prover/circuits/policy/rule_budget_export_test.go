package policy

import (
	"fmt"
	"github.com/consensys/gnark/frontend"
	"github.com/consensys/gnark/std/rangecheck"
	"github.com/helius-labs/zolana/prover/server/circuits/gadget"
	transaction "github.com/helius-labs/zolana/prover/server/circuits/spp_transaction/shared"
	"github.com/reilabs/gnark-lean-extractor/v3/abstractor"
)

// Measurement-only ablation: -1 omits rule evaluation, 0 retains shared
// preparation, and 1..16 evaluates that many dynamic rule slots.
type RuleBudgetCircuit struct {
	MemberPolicyCircuit
	RuleSlots int `gnark:"-"`
}

func NewRuleBudgetCircuit(outputs, slots int) (*RuleBudgetCircuit, error) {
	c, err := NewMemberPolicyCircuit(MemberShape{Outputs: outputs, OwnOnly: true})
	if err != nil {
		return nil, err
	}
	return &RuleBudgetCircuit{MemberPolicyCircuit: *c, RuleSlots: slots}, nil
}

func (b *RuleBudgetCircuit) Define(api frontend.API) error {
	if b.RuleSlots < -1 || b.RuleSlots > NRules {
		return fmt.Errorf("invalid measurement slot count")
	}
	c := &b.MemberPolicyCircuit
	if err := c.validate(transaction.NPublicSlots); err != nil {
		return err
	}
	rc := rangecheck.New(api)
	cmp := c.comparator(rc)
	table := c.Table.decode(api, rc, c.PolicyHash)
	c.assertOwnOnly(api)
	outputs := c.openOutputs(api, c.InputChain)
	sender := c.sender(api)
	c.assertRecipients(api, c.Anonymous, outputs)
	payments := append(append([]utxoView{}, outputs...), c.openWithdrawals(api, rc)...)
	resolved := c.resolveSubjects(api, table, sender, payments)
	if b.RuleSlots >= 0 {
		screen := newPaymentScreen(api, cmp, resolved, payments)
		assertScalarAssets(api, payments, table.scalarOwner)
		for r := 0; r < b.RuleSlots; r++ {
			rule := table.rules[r]
			abstractor.CallVoid(api, gadget.AssertZeroWhen{Cond: api.Mul(table.ruleActive[r], rule.onSender), V: rule.refuses(api, resolved.sender.onList)})
			screen.assert(api, rule, api.Mul(table.ruleActive[r], api.Add(rule.onOwner, rule.onAsset)))
		}
	}
	c.assertApproval(api, c.constrainOutflow(api, cmp, sender, outputs, resolved))
	c.assertEscrow(api, c.KeyEscrow, resolved.owners, outputs)
	bindStatement(api, c.PublicInputHash, c.Statement())
	return nil
}

type TableBudgetCircuit struct {
	Table
	PolicyHash frontend.Variable `gnark:",public"`
}

func (c *TableBudgetCircuit) Define(api frontend.API) error {
	c.Table.decode(api, rangecheck.New(api), c.PolicyHash)
	return nil
}
