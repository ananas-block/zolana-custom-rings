package policy

import (
	"fmt"
	"github.com/consensys/gnark/frontend"
	"github.com/consensys/gnark/std/rangecheck"
	"github.com/helius-labs/zolana-custom-rings/prover/circuits/registry"
	"github.com/helius-labs/zolana-custom-rings/prover/circuits/ringgadget"
	"github.com/helius-labs/zolana/prover/server/circuits/crypto/lookup"
	"github.com/helius-labs/zolana/prover/server/circuits/gadget"
	"github.com/reilabs/gnark-lean-extractor/v3/abstractor"
)

type TaggedRecordExperiment struct {
	TreeID frontend.Variable
	Record registry.Record
}
type TaggedSubjectExperiment struct{ TreeID, Member, RecordIndex frontend.Variable }

type UnifiedPoolExperiment struct {
	MemberPolicyValues
	PolicyInputs
	Records                    []TaggedRecordExperiment
	Subjects                   []TaggedSubjectExperiment
	Canopies                   [2][]frontend.Variable
	Paths                      []registry.SharedQuadPath
	SenderEntry                PoolEntry
	OwnerEntries, AssetEntries []PoolEntry
	PublicAssetEntries         []frontend.Variable
}

func NewUnifiedPoolExperiment(outputs, withdrawals, records, subjects int) (*UnifiedPoolExperiment, error) {
	if records < 1 || subjects < 1 {
		return nil, fmt.Errorf("invalid pool capacity")
	}
	p := newPolicyInputs(outputs, withdrawals, false)
	payments := outputs + withdrawals
	c := &UnifiedPoolExperiment{PolicyInputs: p, Records: make([]TaggedRecordExperiment, records), Subjects: make([]TaggedSubjectExperiment, subjects), Paths: make([]registry.SharedQuadPath, records), SenderEntry: newPoolEntry(false), OwnerEntries: make([]PoolEntry, payments), AssetEntries: make([]PoolEntry, payments), PublicAssetEntries: make([]frontend.Variable, 3)}
	width, levels := 1, 0
	for width < (records+1)/2 {
		width *= 4
		levels++
	}
	for i := range c.Canopies {
		c.Canopies[i] = make([]frontend.Variable, width)
	}
	for i := range c.Paths {
		c.Paths[i].Siblings = make([][registry.Arity - 1]frontend.Variable, registry.Height-levels)
	}
	for i := range c.OwnerEntries {
		c.OwnerEntries[i], c.AssetEntries[i] = newPoolEntry(false), newPoolEntry(false)
	}
	return c, nil
}

func (u *UnifiedPoolExperiment) Define(api frontend.API) error {
	c := &MemberPolicyCircuit{MemberPolicyValues: u.MemberPolicyValues, Policy: Policy{PolicyInputs: u.PolicyInputs}}
	rc := rangecheck.New(api)
	cmp := c.comparator(rc)
	table := c.Table.decode(api, rc, c.PolicyHash)
	outputs := c.openOutputs(api, c.InputChain)
	sender := c.sender(api)
	c.assertRecipients(api, c.Anonymous, outputs)
	payments := append(append([]utxoView{}, outputs...), c.openWithdrawals(api, rc)...)
	resolved := u.resolveUnified(api, table, sender, payments)
	c.assertRules(api, cmp, table, resolved, payments)
	c.assertApproval(api, c.constrainOutflow(api, cmp, sender, outputs, resolved))
	c.assertEscrow(api, c.KeyEscrow, resolved.owners, outputs)
	bindStatement(api, c.PublicInputHash, c.Statement())
	return nil
}

func (u *UnifiedPoolExperiment) resolveUnified(api frontend.API, table tableView, sender frontend.Variable, payments []utxoView) subjects {
	records := lookup.New(api, 3+pooledColumns)
	leaves, trees := make([]frontend.Variable, len(u.Records)), make([]frontend.Variable, len(u.Records))
	for i, tagged := range u.Records {
		api.AssertIsBoolean(tagged.TreeID)
		record := tagged.Record
		leaves[i], trees[i] = record.Hash(api), tagged.TreeID
		row := pooledRecord{escrowKey: record.EscrowKey, onList: sourceLists(api, record.Lists), mintPolicy: decodeMintPolicy(api, record.MintPolicy)}
		records.Insert(row.columns(tagged.TreeID, record.Member, record.Next))
	}
	registry.AssertTaggedSharedExperiment(api, u.OwnRoot, u.CuratorRoot, table.sources.anyForeign, u.Canopies, leaves, trees, u.Paths)
	subjectTable := lookup.New(api, 2+pooledColumns)
	for _, subject := range u.Subjects {
		api.AssertIsBoolean(subject.TreeID)
		active := api.Select(subject.TreeID, table.sources.anyForeign, 1)
		row := records.Lookup(subject.RecordIndex)
		api.AssertIsEqual(row[0], subject.TreeID)
		present := api.IsZero(api.Sub(row[1], subject.Member))
		ringgadget.AssertOrderedWhen(api, api.Mul(active, api.Sub(1, present)), row[1], subject.Member, row[2])
		resolved := pooledRecordAt(row[3:]).gated(api, api.Mul(active, present))
		subjectTable.Insert(resolved.columns(subject.TreeID, subject.Member))
	}
	lookupSubject := func(index, tree, member, active frontend.Variable) pooledRecord {
		row := subjectTable.Lookup(index)
		abstractor.CallVoid(api, gadget.AssertEqualWhen{Cond: active, A: row[0], B: tree})
		abstractor.CallVoid(api, gadget.AssertEqualWhen{Cond: active, A: row[1], B: member})
		return pooledRecordAt(row[2:]).gated(api, active)
	}
	resolve := func(entry PoolEntry, active, member frontend.Variable) (subjectView, mintPolicyWires) {
		own := lookupSubject(entry.Own, 0, member, active)
		curator := lookupSubject(entry.Curator[0], 1, member, api.Mul(active, table.sources.anyForeign))
		return subjectView{onList: table.sources.lists(api, own.onList, curator.onList), escrowKey: own.escrowKey}, own.mintPolicy
	}
	resolved := subjects{owners: make([]subjectView, len(payments)), assets: make([]subjectView, len(payments)), mintPolicies: make([]mintPolicyWires, len(payments))}
	resolved.sender, _ = resolve(u.SenderEntry, 1, sender)
	for i, pay := range payments {
		resolved.owners[i], _ = resolve(u.OwnerEntries[i], pay.utxo, pay.ownerPkHash)
		resolved.assets[i], resolved.mintPolicies[i] = resolve(u.AssetEntries[i], pay.utxo, pay.asset)
	}
	for k, index := range u.PublicAssetEntries {
		asset := u.PublicAssets[k]
		active := ringgadget.IsNonZero(api, asset)
		record := lookupSubject(index, 0, asset, active)
		resolved.publicAssets = append(resolved.publicAssets, publicAsset{asset: asset, active: active, policy: record.mintPolicy})
	}
	return resolved
}
